﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace library
{
    public partial class FrmVirtualKeyboard : frmTemplates 
    {
        public FrmVirtualKeyboard()
        {
            InitializeComponent();
        }

        private void virtualKeyboard_Click(object sender, EventArgs e)
        {

        }
    }
}
