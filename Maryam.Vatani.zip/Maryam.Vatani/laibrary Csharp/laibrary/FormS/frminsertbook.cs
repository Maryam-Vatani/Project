﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace library
{
    public partial class frminsertbook : Form
    {
        public frminsertbook()
        {
            InitializeComponent();
        }

        public bool tc;

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtBookId.Text == "" || txtName.Text == "" || txtAuthor.Text == "" && txtISBN.Text == "" || txtpublisher.Text == "" && txtPublishyear.Text == "" || txtprice.Text == "" && txtPublishyear.Text == "" || txtprice.Text == "" && txtradebandi.Text == "")
                {

                    MessageBox.Show("لطفا تمامی قسمت ها را پر کنید ");
                    return;
                }
                else
                {
                    book b1 = new book();
                    b1.bookId = int.Parse(txtBookId.Text);
                    b1.name = txtName.Text;
                    b1.author = txtAuthor.Text;
                    b1.isbn = txtISBN.Text;
                    b1.publisher = txtpublisher.Text;
                    b1.publishyear = txtPublishyear.Text;
                    b1.price = txtprice.Text;
                    b1.radebandi = txtradebandi.Text;
                    b1.tedad = int.Parse(txtTedad.Text);
                    if (b1.Exist())
                    {

                        b1.tc = true;
                    }
                    else
                    {
                        b1.tc = false;
                    }


                    b1.Insert();

                    dataGridView1.DataSource = b1.show();
                    MessageBox.Show("اطلاعات با موفقیت ثبت شد");
                    txtBookId.Text = txtName.Text = txtAuthor.Text = txtISBN.Text = txtpublisher.Text = txtPublishyear.Text = txtprice.Text = txtradebandi.Text = "";
                }
            }

            catch
            {
                //بررسی فیلد کلید : کد کتاب    
                MessageBox.Show("این کد کتاب قبلا ثبت شده");
            }

        }
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            txtBookId.Text = dataGridView1["BookId", dataGridView1.CurrentRow.Index].Value.ToString();
            txtName.Text = dataGridView1["Name", dataGridView1.CurrentRow.Index].Value.ToString();
            txtAuthor.Text = dataGridView1["Author", dataGridView1.CurrentRow.Index].Value.ToString();
            txtISBN.Text = dataGridView1["ISBN", dataGridView1.CurrentRow.Index].Value.ToString();
            txtpublisher.Text = dataGridView1["publisher", dataGridView1.CurrentRow.Index].Value.ToString();
            txtPublishyear.Text = dataGridView1["Publishyear", dataGridView1.CurrentRow.Index].Value.ToString();
            txtprice.Text = dataGridView1["price", dataGridView1.CurrentRow.Index].Value.ToString();
            txtradebandi.Text = dataGridView1["radebandi", dataGridView1.CurrentRow.Index].Value.ToString();
            txtTedad.Text = dataGridView1["tedad", dataGridView1.CurrentRow.Index].Value.ToString();

        }

        private void frminsertbook_Load(object sender, EventArgs e)
        {
                
                book b1 = new book();
                dataGridView1.DataSource = b1.show();
                
                txtAuthor.Clear();
                txtBookId.Clear();
                txtISBN.Clear();
                txtName.Clear();
                txtBookId.Clear();
                txtBookId.Clear();
                txtpublisher.Clear();
                txtPublishyear.Clear();
                txtradebandi.Clear();
                txtprice.Clear();

                
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button1.Enabled = true;
            BTedit.Visible = false;
            button4.Visible = true;
            int x = dataGridView1.CurrentRow.Index;
            
            book b1 = new book();
            b1.bookId = int.Parse(txtBookId.Text);
            b1.name = txtName.Text;
            b1.author = txtAuthor.Text;
            b1.isbn = txtISBN.Text;
            b1.publisher = txtpublisher.Text;
            b1.publishyear = txtPublishyear.Text;
            b1.price = txtprice.Text;
            b1.radebandi = txtradebandi.Text;
            b1.tedad = int.Parse(txtTedad.Text);
            b1.Update();

            MessageBox.Show("ویرایش با موفقیت انجام شد ");
            dataGridView1.DataSource = b1.show();
            dataGridView1.Rows[x].Selected = true;
            BTedit.Enabled = false;

            txtAuthor.Clear();
            txtBookId.Clear();
            txtISBN.Clear();
            txtName.Clear();
            txtBookId.Clear();
            txtBookId.Clear();
            txtpublisher.Clear();
            txtPublishyear.Clear();
            txtradebandi.Clear();
            txtprice.Clear();
            txtTedad.Clear();
           


        }

        private void bt4delete_Click(object sender, EventArgs e)
        {
            if (txtBookId.Text == "" || txtName.Text == "" || txtAuthor.Text == "" && txtISBN.Text == "" || txtpublisher.Text == "" && txtPublishyear.Text == "" && txtprice.Text == "" && txtradebandi.Text == "")
            {

                MessageBox.Show("برای حذف عضو مورد نظر را انتخاب کنید");
                return;
            }
            else
            {
                DialogResult dr;
                dr = MessageBox.Show("ایا می خواهید رکورد انتخاب شده را خذف نمائید؟", "حذف", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    book b1 = new book();
                    b1.bookId = int.Parse(dataGridView1["bookId", dataGridView1.CurrentRow.Index].Value.ToString());
                    b1.Delete();
                    MessageBox.Show("رکورد انتخاب شده حذف شد");
                    dataGridView1.DataSource = b1.show();
                }
            }
        }



        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            book b1 = new book();
            if (textBox1.Text == "") dataGridView1.DataSource = b1.show();
            if (radioBkCode.Checked == true && textBox1.TextLength > 0)
            {
              
                b1.b = 1;
                b1.bookId = int.Parse(textBox1.Text);
                dataGridView1.DataSource = b1.search();
                
            }
            else if (radioBkName.Checked == true)
            {
                b1.b = 2;
                b1.name = textBox1.Text;
                dataGridView1.DataSource = b1.search();
            }
            else if (radioBkAuthor.Checked == true)
            {
                b1.b = 3;
                b1.author = textBox1.Text;
                dataGridView1.DataSource = b1.search();
            }

        }

        private void radioBkCode_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
          
        }

        private void radioBkName_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
        }

        private void radioBkAuthor_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            BTedit.Enabled = dataGridView1.Enabled = true;
            button1.Enabled = false;
            button4.Visible = false;
            BTedit.Visible = true;
          
        }

        private void حذفToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "" || txtAuthor.Text == "" && txtISBN.Text == "" || txtpublisher.Text == "" && txtPublishyear.Text == "" && txtprice.Text == "" && txtradebandi.Text == "")
            {
                MessageBox.Show("برای حذف عضو مورد نظر را انتخاب کنید");
                return;
            }
            else
            {
                DialogResult dr;
                dr = MessageBox.Show("ایا می خواهید رکورد انتخاب شده را خذف نمائید؟", "حذف", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    book b1 = new book();
                    b1.bookId = int.Parse(dataGridView1["bookId", dataGridView1.CurrentRow.Index].Value.ToString());
                    b1.Delete();
                    MessageBox.Show("رکورد انتخاب شده حذف شد");
                    dataGridView1.DataSource = b1.show();
                }
            }
        }

        private void بروزرسانیToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtName.Focus();
        }

        private void خروجToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '\b') e.Handled = false;
            else e.Handled = true;
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
          
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (radioBkCode.Checked == true)
            {
                if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '\b') e.Handled = false;
                else e.Handled = true;
            }
        }
        private void groupPanel2_Click(object sender, EventArgs e)
        {

        }

        private void btExit_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void btback_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridViewX1_SelectionChanged(object sender, EventArgs e)
        {
            txtBookId.Text = dataGridView1["BookId", dataGridView1.CurrentRow.Index].Value.ToString();
            txtName.Text = dataGridView1["Name", dataGridView1.CurrentRow.Index].Value.ToString();
            txtAuthor.Text = dataGridView1["Author", dataGridView1.CurrentRow.Index].Value.ToString();
            txtISBN.Text = dataGridView1["ISBN", dataGridView1.CurrentRow.Index].Value.ToString();
            txtpublisher.Text = dataGridView1["publisher", dataGridView1.CurrentRow.Index].Value.ToString();
            txtPublishyear.Text = dataGridView1["Publishyear", dataGridView1.CurrentRow.Index].Value.ToString();
            txtprice.Text = dataGridView1["price", dataGridView1.CurrentRow.Index].Value.ToString();
            txtradebandi.Text = dataGridView1["radebandi", dataGridView1.CurrentRow.Index].Value.ToString();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            label9.Text = dataGridView1.RowCount.ToString(); 


        }
    }
}


    

