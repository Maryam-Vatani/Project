﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace library
{
    public partial class FrmUser : frmTemplates 

    {
        public FrmUser()
        {
            InitializeComponent();
        }

        private void buttonX1_Click(object sender, EventArgs e)
        {
            if (txtpass2.Text != txtPass.Text)
            {
                MessageBox.Show("هر دو رمز عبور باید یکسان باشد");
            }
            else
            {
                UserPass up = new UserPass();
                up.name = txtName.Text;
                up.pass = txtPass.Text.GetHashCode().ToString();
                up.admin = radioBtAdmin.Checked;
                up.Insert();
                MessageBox.Show("نام کاربری با موفقیت ثبت شد");
                this.Close();

            }
        }

        private void FrmUser_Load(object sender, EventArgs e)
        {

            UserPass  users = new UserPass ();
            DataGridUsers.DataSource = users.show();
        }

        private void buttonX2_Click(object sender, EventArgs e)
        {
            DialogResult dr;
            dr = MessageBox.Show("ایا می خواهید رکورد انتخاب شده را خذف نمائید؟", "حذف", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                UserPass users = new UserPass();
                users.Id = int.Parse(DataGridUsers["Id", DataGridUsers.CurrentRow.Index].Value.ToString());
                users.Delete();
                MessageBox.Show("رکورد انتخاب شده حذف شد");
                DataGridUsers.DataSource = users.show();

                //DataGridUsers.Rows[0].Selected = false;
                //DataGridUsers.CurrentCell = DataGridUsers.Rows[DataGridUsers.RowCount - 1].Cells[0];
            }
        }

        private void DataGridUsers_SelectionChanged(object sender, EventArgs e)
        {
            txtName.Text  = DataGridUsers["name", DataGridUsers.CurrentRow.Index].Value.ToString();
            txtPass.Text = DataGridUsers["pass", DataGridUsers.CurrentRow.Index].Value.ToString();
        }

    }
}
