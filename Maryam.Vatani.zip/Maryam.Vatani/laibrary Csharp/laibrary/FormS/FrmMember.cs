﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace library
{
    public partial class FrmMember : Form
    {
        public FrmMember()
        {
            InitializeComponent();
        }

        private void FrmMember_Load(object sender, EventArgs e)
        {
            member m1 = new member();
            dataGridView1.DataSource = m1.show();
            txtName.Text = txtId.Text = txtName.Text = txtfamily.Text = txtTel.Text = txtaddress.Text = "";
        }

        private void btInsert_Click(object sender, EventArgs e)
        {
            try
            {

                if (txtId.Text == "" || txtName.Text == "" && txtfamily.Text == "" || txtTel.Text == "" && txtaddress.Text == "")
                {

                    MessageBox.Show("لطفا تمامی قسمت ها را پر کنید ");
                    return;
                }
                else
                {
                    member m1 = new member();
                    m1.MemberId = int.Parse(txtId.Text);
                    m1.name = txtName.Text;
                    m1.family = txtfamily.Text;
                    m1.tel = Int64.Parse(txtTel.Text);
                    m1.address = txtaddress.Text;
                    m1.Insert();
                    dataGridView1.DataSource = m1.show();
                    DialogResult dr;
                    dr = MessageBox.Show (" با موفقیت ثبت شد. آیا می خواهید کد جدیدی را ثبت نمایید؟", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dr == DialogResult.Yes)
                    {
                        txtaddress.Clear();
                        txtfamily.Clear();
                        txtId.Clear();
                        txtName.Clear();
                        txtTel.Clear();
                        txtName.Focus();
                        dataGridView1.CurrentCell = dataGridView1.Rows[dataGridView1.RowCount - 1].Cells[0];

                    }
                    btDelete.Enabled = true;
                    txtName.Focus();
                }
            }
            catch
            {
                MessageBox.Show("این کد عضویت قبلا ثبت شده است");
                txtId.Focus();
           
            }
        }

        private void btDelete_Click(object sender, EventArgs e)
        {
            DialogResult dr;
            dr = MessageBox.Show("ایا می خواهید رکورد انتخاب شده را خذف نمائید؟", "حذف", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                member m1 = new member();
                m1.MemberId = int.Parse(dataGridView1["MemberId", dataGridView1.CurrentRow.Index].Value.ToString());
                m1.Delete();
                MessageBox.Show("رکورد انتخاب شده حذف شد");
                dataGridView1.DataSource = m1.show();
                //btDelete.Enabled = false;
                btInsert.Enabled = true;

            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {

            txtId.Text = dataGridView1["MemberId", dataGridView1.CurrentRow.Index].Value.ToString();
            txtName.Text = dataGridView1["name", dataGridView1.CurrentRow.Index].Value.ToString();
            txtfamily.Text = dataGridView1["family", dataGridView1.CurrentRow.Index].Value.ToString();
            txtTel.Text = dataGridView1["tel", dataGridView1.CurrentRow.Index].Value.ToString();
            txtaddress.Text = dataGridView1["address", dataGridView1.CurrentRow.Index].Value.ToString();

        }

        private void btEdit_Click(object sender, EventArgs e)
        {
            btInsert.Enabled = true;
            btEdit.Enabled = false;
            btEdit.Visible = false;
            button1.Visible = true;

            int x = dataGridView1.CurrentRow.Index;
            
            member m1 = new member();
            m1.MemberId = int.Parse(txtId.Text);
            m1.name = txtName.Text;
            m1.family = txtfamily.Text;
            m1.tel = Int64.Parse(txtTel.Text);
            m1.address = txtaddress.Text;
            //m1.MemberId = int.Parse(dataGridView1["MemberId", dataGridView1.CurrentRow.Index].Value.ToString());
            m1.Update();
            MessageBox.Show("ویرایش با موفقیت انجام شد ");
            dataGridView1.DataSource = m1.show();

            dataGridView1.Rows[0].Selected = false;
            dataGridView1.Rows[x].Selected = true;
            txtName.Text = txtId.Text = txtName.Text = txtfamily.Text = txtTel.Text = txtaddress.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
   
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            member m1 = new member();
            if (textBox1.Text == "") dataGridView1.DataSource = m1.show();
            if (radioBtName.Checked == true && textBox1.TextLength > 0)
            {
                m1.m = 1;
                m1.name = textBox1.Text;
                dataGridView1.DataSource = m1.search();
            }
            else if (radioBtFamily.Checked == true)
            {
                m1.m = 2;
                m1.family = textBox1.Text;
                dataGridView1.DataSource = m1.search();
            }
            else if (radioBCity.Checked == true)
            {
                m1.m = 3;
                m1.address = textBox1.Text;
                dataGridView1.DataSource = m1.search();
            }
        }

        private void txtTel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '\b') e.Handled = false;
            else e.Handled = true;

        }

        private void txtId_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '\b') e.Handled = false;
            else e.Handled = true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            btEdit.Enabled=  true;
            btEdit.Visible = true;
            button1.Visible = false;
            btInsert.Enabled = false;

        }

        private void BtExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            labelkol.Text = dataGridView1.RowCount.ToString(); 
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
