﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace library
{
    public partial class FrmUserPass : Form
    {
        public FrmUserPass()
        {
            InitializeComponent();
        }

        bool K;
        
        public static Boolean Adminuser = false;

        private void BtEnter_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "" || txtPass.Text == "")
            {
                MessageBox.Show("نام کاربری و رمز عبور را وارد کنید ");
            }
            else
            {
                UserPass up = new UserPass();
                up.name = txtName.Text;
                up.pass = txtPass.Text.GetHashCode().ToString();
                if (up.Exist())
                {

                    this.Visible = false;
                    new FrmLoad().ShowDialog();
                    this.Close();
                }
                MessageBox.Show("نام کاربری یا کلمه عبور اشتباه می باشد");
            }
        }

        private void elButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void BTvKeyboard_Click(object sender, EventArgs e)
        {
            new FrmVirtualKeyboard().ShowDialog(); 

        }

        private void elButton1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtPass_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                BtEnter_Click(null, null);

            }
        }


      
        private void FrmUserPass_Load(object sender, EventArgs e)
        {

        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                BtEnter_Click(null, null);

            }
        }

        private void keyboardControl2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (K)
            {
                this.Height += 5;
                if (this.Height == 290) timer1.Enabled = false;
            }
            else
            {
                this.Height -= 5;
                if (this.Height == 45) timer1.Enabled = false;
            }
        }

        private void elButton2_Click(object sender, EventArgs e)
        {
            K =! K;
            timer1.Enabled = true;
        }

    }
}
