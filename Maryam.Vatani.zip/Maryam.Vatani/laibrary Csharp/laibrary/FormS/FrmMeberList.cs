﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace library
{
    public partial class FrmMeberList : Form
    {
        public FrmMeberList()
        {
            InitializeComponent();
        }

        private void FrmMeberList_Load(object sender, EventArgs e)
        {
            member m1 = new member();
            dataGridView1.DataSource = m1.show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
