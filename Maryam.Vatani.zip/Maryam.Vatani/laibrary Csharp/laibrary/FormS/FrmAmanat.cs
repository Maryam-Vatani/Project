﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;

namespace library
{
    public partial class FrmAmanat : Form
    {
        public FrmAmanat()
        {
            InitializeComponent();
        }

        private void btadd_Click(object sender, EventArgs e)
        {
            try
            {
                FrmM fme = new FrmM();
                fme.ShowDialog();
                txtMemberId.Text = fme.dataGridView1["MemberId", fme.dataGridView1.CurrentRow.Index].Value.ToString();
                txtMemberName.Text = fme.dataGridView1["name", fme.dataGridView1.CurrentRow.Index].Value.ToString();
                txtMemberFamily.Text = fme.dataGridView1["family", fme.dataGridView1.CurrentRow.Index].Value.ToString();
            
            }
            catch
            {
                MessageBox.Show("ERRoR");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                FrmB f1 = new FrmB();
                f1.ShowDialog();
                txtBookId.Text = f1.dataGridView1["bookId", f1.dataGridView1.CurrentRow.Index].Value.ToString();
                txtNameBook.Text = f1.dataGridView1["name", f1.dataGridView1.CurrentRow.Index].Value.ToString();
                
            }
            catch
            {
                MessageBox.Show("ERRoR");
            }
        }
        /// <summary>
        /// امانت ثبت
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>



        private void FrmAmanat_Load(object sender, EventArgs e)
        {
            txtAmanatId.Text = txtBookId.Text = txtMemberFamily.Text = txtMemberId.Text = txtNameBook.Text = txtMemberName.Text = "";
            txtDateSabt.Text = shamsi(DateTime.Now);
            txtReturn.Text = shamsi2(DateTime.Now);
            Amanat amn = new Amanat();
            DatagAmanat.DataSource = amn.show();
            DatagAmanat.CurrentCell = DatagAmanat.Rows[DatagAmanat.RowCount - 1].Cells[0];
        }

        string shamsi(DateTime today)
        {
            PersianCalendar pc = new PersianCalendar();
            return pc.GetYear(today).ToString("0000") + pc.GetMonth(today).ToString("/00") + pc.GetDayOfMonth(today).ToString("/00");
        }

        string shamsi2(DateTime today2)
        {
            PersianCalendar pc1 = new PersianCalendar();
            return pc1.GetYear(today2).ToString("0000") + (1 + pc1.GetMonth(today2)).ToString("/00") + pc1.GetDayOfMonth(today2).ToString("/00");
           
        }

        private void buttonX1_Click(object sender, EventArgs e)
        {
            txtReturn.Enabled = true;
        }

        private void BtDelete_Click(object sender, EventArgs e)
        {
            if (DatagAmanat.CurrentRow != null)
            {
                DialogResult dr;
                dr = MessageBox.Show("ایا می خواهید رکورد انتخاب شده را خذف نمائید؟", "حذف", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    Amanat b1 = new Amanat();
                    book b = new book();
                    b1.AmanatId = int.Parse(DatagAmanat["AmanatId", DatagAmanat.CurrentRow.Index].Value.ToString());
                    b1.Delete();
                    MessageBox.Show("رکورد انتخاب شده حذف شد");
                    DatagAmanat.DataSource = b1.show();
                    b.tedad = +1;
                    b.bookId = int.Parse(DatagAmanat["bookId", DatagAmanat.CurrentRow.Index].Value.ToString());
                    b.tc = true;
                    b.Insert();
                }
            }
            else
            {
                MessageBox.Show("لطفاً سطر مورد نظر را از جدول مقابل انتخاب نمائید");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtReturn.Enabled = true;
           
            BtSabtAmanat.Enabled = false;
            DatagAmanat.Enabled = true;
            button4.Enabled = true;
            button4.Visible = true;
          
        }

        private void DatagAmanat_SelectionChanged(object sender, EventArgs e)
        {
            if (DatagAmanat.CurrentRow != null)
            {
                int index = DatagAmanat.CurrentRow.Index;

                txtBookId.Text = DatagAmanat["bookId", index].Value.ToString();
                txtMemberId.Text = DatagAmanat["MemberId", index].Value.ToString();
                txtNameBook.Text = DatagAmanat["bookName", index].Value.ToString();
                txtMemberName.Text = DatagAmanat["MemberName", index].Value.ToString();
                txtMemberFamily.Text = DatagAmanat["family", index].Value.ToString();
                txtDateSabt.Text = DatagAmanat["DateSabt", index].Value.ToString();
                txtReturn.Text = DatagAmanat["ReturnDate", index].Value.ToString();
                txtAmanatId.Text = DatagAmanat["AmanatId", index].Value.ToString();
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            Amanat a1 = new Amanat();
            if (txtSearch.Text == "") DatagAmanat.DataSource = a1.show();
            if (radioBtMemberId.Checked == true && txtSearch.TextLength > 0)
            {
                a1.a = 1;
                a1.MemberId = int.Parse(txtSearch.Text);
                DatagAmanat.DataSource = a1.search();
            }
            else if (radioBtBookName.Checked == true)
            {
                a1.a = 2;
                a1.BookName = txtSearch.Text;
                DatagAmanat.DataSource = a1.search();
            }
            else if (radioBtFamily.Checked == true)
            {
                a1.a = 3;
                a1.Family = txtSearch.Text;
                DatagAmanat.DataSource = a1.search();
            }
        }

        private void elRichPanel2_Click(object sender, EventArgs e)
        {

        }

        private void BtSabtAmanat_Click(object sender, EventArgs e)
        {
            if (txtAmanatId.Text.Length != 0 && txtMemberId.Text.Length != 0 && txtBookId.Text.Length != 0)
            {
                Amanat amn = new Amanat();
                book b = new book();

                amn.bookId = int.Parse(txtBookId.Text);
                amn.MemberId = int.Parse(txtMemberId.Text);
                amn.BookName = (txtNameBook.Text);
                amn.MemberName = (txtMemberName.Text);
                amn.Family = (txtMemberFamily.Text);
                amn.DateSabt = (txtDateSabt.Text);
                amn.ReturnDate = (txtReturn.Text);
                amn.AmanatId = int.Parse(txtAmanatId.Text);
                amn.Insert();
                DatagAmanat.DataSource = amn.show();

                MessageBox.Show("اطلاعات با موفقیت ثبت شد");

                DatagAmanat.CurrentCell = DatagAmanat.Rows[DatagAmanat.RowCount - 1].Cells[0];
                b.tedad = -1;
                b.bookId = int.Parse(txtBookId.Text);
                b.tc = true;
                b.Insert();
            }
        }
        private void BtReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void button2_Click(object sender, EventArgs e)
        {
            int a, b, c, aaa, bbb;
            string aa, bb;
            PersianCalendar cc = new PersianCalendar();
            a = int.Parse(txtDateSabt.Text.Remove(0, 8));
            b = int.Parse(txtReturn.Text.Remove(0, 8));
            bb = txtReturn.Text.Remove(0, 5);
            bb = bb.Remove(2, 3);
            aa = txtDateSabt.Text.Remove(0, 5);
            aa = aa.Remove(2, 3);
            aaa = int.Parse(txtDateSabt.Text.Remove(4, 6));
            bbb = int.Parse(txtReturn.Text.Remove(4, 6));

                if (aaa > bbb)
                {
                 
                    c =  a + 360 - b; 
                    c = c * 200;
                    MessageBox.Show("میزان جریمه :" + c.ToString());
                }
                else if (int.Parse(aa) > int.Parse(bb))
                    {
                        c = a + 30 - b;
                        c = c * 200;
                        MessageBox.Show("میزان جریمه :" + c.ToString());
                    }

                    else if (int.Parse(aa) == int.Parse(bb))
                    {
                        c = a - b;
                        c = c * 200;
                        MessageBox.Show("میزان جریمه :" + c.ToString());
                    }
                    else MessageBox.Show("Mohlat Darad");
                }

        private void DatagAmanat_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtDateSabt_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (DatagAmanat.CurrentRow != null)
            {
                txtReturn.Enabled = false;

                Amanat amn = new Amanat();
                //amn.bookId = int.Parse(txtBookId.Text);
                //amn.MemberId = int.Parse(txtMemberId.Text);
                //amn.BookName = (txtNameBook.Text);
                //amn.MemberName = (txtMemberName.Text);
                //amn.Family = (txtMemberFamily.Text);
                // amn.DateSabt = (txtDateSabt.Text);
                amn.ReturnDate = (txtReturn.Text);
                amn.AmanatId = int.Parse(txtAmanatId.Text);
                //b1.bookId = Int64.Parse(dataGridView1["bookId", dataGridView1.CurrentRow.Index].Value.ToString());
                amn.Update();
                MessageBox.Show("ویرایش با موفقیت انجام شد ");
                button4.Visible = false;
                BtSabtAmanat.Enabled = true;
                DatagAmanat.DataSource = amn.show();
            }
            else
            {
                MessageBox.Show("لطفاً سطر مورد نظر را از جدول مقابل انتخاب نمائید");
            }
        }

        private void txtReturn_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMemberId_TextChanged(object sender, EventArgs e)
        {

        }
    }
}