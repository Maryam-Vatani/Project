﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace library
{
    public partial class FrmAmanatNew : frmTemplates 
    {
        public FrmAmanatNew()
        {
            InitializeComponent();
        }
     

        private void FrmAmanatNew_Load(object sender, EventArgs e)
        {
            Amanat amn = new Amanat();
            DatagAmanat.DataSource = amn.show();
            DatagAmanat.CurrentCell = DatagAmanat.Rows[DatagAmanat.RowCount - 1].Cells[0];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string a;
            a = (DatagAmanat.RowCount - 1).ToString();
            if (txtSearch.Text == "")
            {
                
                MessageBox.Show("لطفا کد کاربر را وارد کنید");
            }
            else if (int.Parse(a) == 0)
            {
                MessageBox.Show("کاربری با این کد کتابی امانت نگرفته است ");

            }
            else
            {
              MessageBox.Show("  تعداد  "+a+   "  کتاب امانت گرفته است  " );   
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            Amanat a1 = new Amanat();
            if (txtSearch.Text == "")
            {
                button1.Enabled = false;
                DatagAmanat.DataSource = a1.show();

            }
            else
            {
                button1.Enabled = true;
                
                a1.a = 1;
                a1.MemberId = int.Parse(txtSearch.Text);
                DatagAmanat.DataSource = a1.search();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
          
            FrmM f =new FrmM();
            f.ShowDialog();
            txtSearch.Text = f.dataGridView1["MemberId", f.dataGridView1.CurrentRow.Index].Value.ToString();
         

        }
    }
}
