﻿namespace library
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.مدیریتکتابخانهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتوویرایشکتابToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.لیستکتبموجودToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.پرینتلیستگتبToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مدیریتاعضاءToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتوویرایشاعضاءToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.لیستاعضاءToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.پرینتلیستاعضاءToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.منویامانتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتامانتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.گزارشگیریToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.دربارهبرنامهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتکاربرجدیدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتکاربرجدیدToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.دربارهنرمافزارToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.گزارشToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.امانتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.headerButton1 = new Klik.Windows.Forms.v1.Common.HeaderButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.elButton1 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elRichPanel1 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.elButton2 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton3 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton4 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton5 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).BeginInit();
            this.elRichPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).BeginInit();
            this.SuspendLayout();
            // 
            // مدیریتکتابخانهToolStripMenuItem
            // 
            this.مدیریتکتابخانهToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ثبتوویرایشکتابToolStripMenuItem,
            this.لیستکتبموجودToolStripMenuItem,
            this.پرینتلیستگتبToolStripMenuItem});
            this.مدیریتکتابخانهToolStripMenuItem.Name = "مدیریتکتابخانهToolStripMenuItem";
            resources.ApplyResources(this.مدیریتکتابخانهToolStripMenuItem, "مدیریتکتابخانهToolStripMenuItem");
            // 
            // ثبتوویرایشکتابToolStripMenuItem
            // 
            this.ثبتوویرایشکتابToolStripMenuItem.Name = "ثبتوویرایشکتابToolStripMenuItem";
            resources.ApplyResources(this.ثبتوویرایشکتابToolStripMenuItem, "ثبتوویرایشکتابToolStripMenuItem");
            this.ثبتوویرایشکتابToolStripMenuItem.Click += new System.EventHandler(this.ثبتوویرایشکتابToolStripMenuItem_Click);
            // 
            // لیستکتبموجودToolStripMenuItem
            // 
            this.لیستکتبموجودToolStripMenuItem.Name = "لیستکتبموجودToolStripMenuItem";
            resources.ApplyResources(this.لیستکتبموجودToolStripMenuItem, "لیستکتبموجودToolStripMenuItem");
            this.لیستکتبموجودToolStripMenuItem.Click += new System.EventHandler(this.لیستکتبموجودToolStripMenuItem_Click);
            // 
            // پرینتلیستگتبToolStripMenuItem
            // 
            this.پرینتلیستگتبToolStripMenuItem.Name = "پرینتلیستگتبToolStripMenuItem";
            resources.ApplyResources(this.پرینتلیستگتبToolStripMenuItem, "پرینتلیستگتبToolStripMenuItem");
            // 
            // مدیریتاعضاءToolStripMenuItem
            // 
            this.مدیریتاعضاءToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ثبتوویرایشاعضاءToolStripMenuItem1,
            this.لیستاعضاءToolStripMenuItem,
            this.پرینتلیستاعضاءToolStripMenuItem});
            this.مدیریتاعضاءToolStripMenuItem.Name = "مدیریتاعضاءToolStripMenuItem";
            resources.ApplyResources(this.مدیریتاعضاءToolStripMenuItem, "مدیریتاعضاءToolStripMenuItem");
            // 
            // ثبتوویرایشاعضاءToolStripMenuItem1
            // 
            this.ثبتوویرایشاعضاءToolStripMenuItem1.Name = "ثبتوویرایشاعضاءToolStripMenuItem1";
            resources.ApplyResources(this.ثبتوویرایشاعضاءToolStripMenuItem1, "ثبتوویرایشاعضاءToolStripMenuItem1");
            this.ثبتوویرایشاعضاءToolStripMenuItem1.Click += new System.EventHandler(this.ثبتوویرایشاعضاءToolStripMenuItem1_Click);
            // 
            // لیستاعضاءToolStripMenuItem
            // 
            this.لیستاعضاءToolStripMenuItem.Name = "لیستاعضاءToolStripMenuItem";
            resources.ApplyResources(this.لیستاعضاءToolStripMenuItem, "لیستاعضاءToolStripMenuItem");
            this.لیستاعضاءToolStripMenuItem.Click += new System.EventHandler(this.لیستاعضاءToolStripMenuItem_Click);
            // 
            // پرینتلیستاعضاءToolStripMenuItem
            // 
            this.پرینتلیستاعضاءToolStripMenuItem.Name = "پرینتلیستاعضاءToolStripMenuItem";
            resources.ApplyResources(this.پرینتلیستاعضاءToolStripMenuItem, "پرینتلیستاعضاءToolStripMenuItem");
            // 
            // منویامانتToolStripMenuItem
            // 
            this.منویامانتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ثبتامانتToolStripMenuItem,
            this.گزارشگیریToolStripMenuItem});
            this.منویامانتToolStripMenuItem.Name = "منویامانتToolStripMenuItem";
            resources.ApplyResources(this.منویامانتToolStripMenuItem, "منویامانتToolStripMenuItem");
            // 
            // ثبتامانتToolStripMenuItem
            // 
            this.ثبتامانتToolStripMenuItem.Name = "ثبتامانتToolStripMenuItem";
            resources.ApplyResources(this.ثبتامانتToolStripMenuItem, "ثبتامانتToolStripMenuItem");
            this.ثبتامانتToolStripMenuItem.Click += new System.EventHandler(this.ثبتامانتToolStripMenuItem_Click);
            // 
            // گزارشگیریToolStripMenuItem
            // 
            this.گزارشگیریToolStripMenuItem.Name = "گزارشگیریToolStripMenuItem";
            resources.ApplyResources(this.گزارشگیریToolStripMenuItem, "گزارشگیریToolStripMenuItem");
            // 
            // دربارهبرنامهToolStripMenuItem
            // 
            this.دربارهبرنامهToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ثبتکاربرجدیدToolStripMenuItem});
            this.دربارهبرنامهToolStripMenuItem.Name = "دربارهبرنامهToolStripMenuItem";
            resources.ApplyResources(this.دربارهبرنامهToolStripMenuItem, "دربارهبرنامهToolStripMenuItem");
            // 
            // ثبتکاربرجدیدToolStripMenuItem
            // 
            this.ثبتکاربرجدیدToolStripMenuItem.Name = "ثبتکاربرجدیدToolStripMenuItem";
            resources.ApplyResources(this.ثبتکاربرجدیدToolStripMenuItem, "ثبتکاربرجدیدToolStripMenuItem");
            // 
            // notifyIcon1
            // 
            resources.ApplyResources(this.notifyIcon1, "notifyIcon1");
            this.notifyIcon1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseClick);
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.menuStrip2, "menuStrip2");
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem5,
            this.toolStripMenuItem9,
            this.toolStripMenuItem12,
            this.دربارهنرمافزارToolStripMenuItem,
            this.گزارشToolStripMenuItem});
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem3});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            resources.ApplyResources(this.toolStripMenuItem1, "toolStripMenuItem1");
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            resources.ApplyResources(this.toolStripMenuItem2, "toolStripMenuItem2");
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            resources.ApplyResources(this.toolStripMenuItem3, "toolStripMenuItem3");
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem6,
            this.toolStripMenuItem7});
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            resources.ApplyResources(this.toolStripMenuItem5, "toolStripMenuItem5");
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            resources.ApplyResources(this.toolStripMenuItem6, "toolStripMenuItem6");
            this.toolStripMenuItem6.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            resources.ApplyResources(this.toolStripMenuItem7, "toolStripMenuItem7");
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem10});
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            resources.ApplyResources(this.toolStripMenuItem9, "toolStripMenuItem9");
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            resources.ApplyResources(this.toolStripMenuItem10, "toolStripMenuItem10");
            this.toolStripMenuItem10.Click += new System.EventHandler(this.toolStripMenuItem10_Click);
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ثبتکاربرجدیدToolStripMenuItem1});
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            resources.ApplyResources(this.toolStripMenuItem12, "toolStripMenuItem12");
            // 
            // ثبتکاربرجدیدToolStripMenuItem1
            // 
            this.ثبتکاربرجدیدToolStripMenuItem1.Name = "ثبتکاربرجدیدToolStripMenuItem1";
            resources.ApplyResources(this.ثبتکاربرجدیدToolStripMenuItem1, "ثبتکاربرجدیدToolStripMenuItem1");
            this.ثبتکاربرجدیدToolStripMenuItem1.Click += new System.EventHandler(this.ثبتکاربرجدیدToolStripMenuItem1_Click);
            // 
            // دربارهنرمافزارToolStripMenuItem
            // 
            this.دربارهنرمافزارToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.دربارهنرمافزارToolStripMenuItem.Name = "دربارهنرمافزارToolStripMenuItem";
            resources.ApplyResources(this.دربارهنرمافزارToolStripMenuItem, "دربارهنرمافزارToolStripMenuItem");
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            resources.ApplyResources(this.aboutToolStripMenuItem, "aboutToolStripMenuItem");
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click_1);
            // 
            // گزارشToolStripMenuItem
            // 
            this.گزارشToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.امانتToolStripMenuItem});
            this.گزارشToolStripMenuItem.Name = "گزارشToolStripMenuItem";
            resources.ApplyResources(this.گزارشToolStripMenuItem, "گزارشToolStripMenuItem");
            // 
            // امانتToolStripMenuItem
            // 
            this.امانتToolStripMenuItem.Name = "امانتToolStripMenuItem";
            resources.ApplyResources(this.امانتToolStripMenuItem, "امانتToolStripMenuItem");
            this.امانتToolStripMenuItem.Click += new System.EventHandler(this.امانتToolStripMenuItem_Click);
            // 
            // headerButton1
            // 
            this.headerButton1.BackgroundStyle.GradientAngle = 45F;
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Name = "label2";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Name = "label1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // elButton1
            // 
            this.elButton1.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elButton1.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elButton1.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            resources.ApplyResources(this.elButton1, "elButton1");
            this.elButton1.Name = "elButton1";
            this.elButton1.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elButton1.TextStyle.Text = resources.GetString("resource.Text");
            this.elButton1.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elButton1.VisualStyle = Klik.Windows.Forms.v1.EntryLib.ButtonVisualStyles.ToolBar;
            this.elButton1.Click += new System.EventHandler(this.elButton1_Click_2);
            // 
            // elRichPanel1
            // 
            this.elRichPanel1.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.ContainerStyle.BorderStyle.SmoothingMode = Klik.Windows.Forms.v1.Common.SmoothingModes.AntiAlias;
            this.elRichPanel1.Controls.Add(this.label4);
            this.elRichPanel1.Controls.Add(this.label2);
            this.elRichPanel1.Controls.Add(this.label1);
            this.elRichPanel1.Controls.Add(this.label3);
            this.elRichPanel1.Controls.Add(this.elButton1);
            resources.ApplyResources(this.elRichPanel1, "elRichPanel1");
            this.elRichPanel1.Expanded = true;
            this.elRichPanel1.FooterStyle.BackgroundStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.FooterStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.elRichPanel1.FooterStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel1.FooterStyle.TextStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(83)))), ((int)(((byte)(92)))));
            this.elRichPanel1.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.HeaderStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.elRichPanel1.HeaderStyle.Height = 24;
            this.elRichPanel1.HeaderStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel1.HeaderStyle.TextStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(83)))), ((int)(((byte)(92)))));
            this.elRichPanel1.HeaderStyle.TextStyle.Text = resources.GetString("resource.Text1");
            this.elRichPanel1.Name = "elRichPanel1";
            this.elRichPanel1.Click += new System.EventHandler(this.elRichPanel1_Click);
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Name = "label4";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.AutoEllipsis = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Name = "label3";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // elButton2
            // 
            this.elButton2.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elButton2.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elButton2.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            resources.ApplyResources(this.elButton2, "elButton2");
            this.elButton2.Name = "elButton2";
            this.elButton2.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.elButton2.TextStyle.Text = resources.GetString("resource.Text2");
            this.elButton2.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elButton2.VisualStyle = Klik.Windows.Forms.v1.EntryLib.ButtonVisualStyles.ToolBar;
            this.elButton2.Click += new System.EventHandler(this.elButton2_Click_3);
            // 
            // elButton3
            // 
            this.elButton3.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elButton3.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elButton3.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            resources.ApplyResources(this.elButton3, "elButton3");
            this.elButton3.Name = "elButton3";
            this.elButton3.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.elButton3.TextStyle.Text = resources.GetString("resource.Text3");
            this.elButton3.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elButton3.VisualStyle = Klik.Windows.Forms.v1.EntryLib.ButtonVisualStyles.ToolBar;
            this.elButton3.Click += new System.EventHandler(this.elButton3_Click_3);
            // 
            // elButton4
            // 
            this.elButton4.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elButton4.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elButton4.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            resources.ApplyResources(this.elButton4, "elButton4");
            this.elButton4.Name = "elButton4";
            this.elButton4.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.elButton4.TextStyle.Text = resources.GetString("resource.Text4");
            this.elButton4.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elButton4.VisualStyle = Klik.Windows.Forms.v1.EntryLib.ButtonVisualStyles.ToolBar;
            this.elButton4.Click += new System.EventHandler(this.elButton4_Click_3);
            // 
            // elButton5
            // 
            this.elButton5.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elButton5.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elButton5.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            resources.ApplyResources(this.elButton5, "elButton5");
            this.elButton5.Name = "elButton5";
            this.elButton5.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elButton5.TextStyle.Text = resources.GetString("resource.Text5");
            this.elButton5.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elButton5.VisualStyle = Klik.Windows.Forms.v1.EntryLib.ButtonVisualStyles.ToolBar;
            this.elButton5.Click += new System.EventHandler(this.elButton5_Click_3);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // FrmMain
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.elButton5);
            this.Controls.Add(this.elButton4);
            this.Controls.Add(this.elRichPanel1);
            this.Controls.Add(this.elButton3);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.elButton2);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "FrmMain";
            this.ShowInTaskbar = false;
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).EndInit();
            this.elRichPanel1.ResumeLayout(false);
            this.elRichPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem مدیریتکتابخانهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتوویرایشکتابToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مدیریتاعضاءToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتوویرایشاعضاءToolStripMenuItem1;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolStripMenuItem لیستکتبموجودToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem لیستاعضاءToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem پرینتلیستگتبToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem پرینتلیستاعضاءToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem منویامانتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتامانتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem گزارشگیریToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem دربارهبرنامهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتکاربرجدیدToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem ثبتکاربرجدیدToolStripMenuItem1;
        private Klik.Windows.Forms.v1.Common.HeaderButton headerButton1;
        private System.Windows.Forms.ToolStripMenuItem دربارهنرمافزارToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton1;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel1;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton2;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton3;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton4;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton5;
        private System.Windows.Forms.ToolStripMenuItem گزارشToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem امانتToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}