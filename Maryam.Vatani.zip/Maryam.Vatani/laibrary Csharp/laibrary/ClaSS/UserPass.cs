﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;


namespace library
{
    public class UserPass
    {
        public int Id;
        public string name;
        public string pass;
        public bool admin;


        public bool Exist()
        {

            OleDbCommand com = new OleDbCommand();
            com.CommandText = "select * from  UserPass where name=@name and pass=@pass";
            com.Parameters.AddWithValue("@name", name);
            com.Parameters.AddWithValue("@pass", pass);
            DataAccess da = new DataAccess();
            da.Connect();
            DataTable dt = da.Docommand(com);
            da.Disconnect();
            if (dt.Rows.Count > 0)
            {
                FrmUserPass.Adminuser = Boolean.Parse(dt.Rows[0]["admin"].ToString());
                return true;
            }

            return false;

        }

        public void Insert()
        {
            DataAccess me = new DataAccess();
            me.Connect();
            OleDbCommand com = new OleDbCommand();
            com.CommandText = "insert into UserPass(name,pass,admin)values(@name,@pass,@admin)";
            com.Parameters.AddWithValue("@name", name);
            com.Parameters.AddWithValue("@pass", pass);
            com.Parameters.AddWithValue("@admin", admin);
            me.Command(com);
            me.Disconnect();
        }

        public void Delete()
        {
            var da = new DataAccess();
            da.Connect();
            var com = new OleDbCommand();
            com.CommandText = "delete from UserPass where Id=@Id";
            com.Parameters.AddWithValue("@Id", Id);
            da.Command(com);
            da.Disconnect();
        }

        public DataTable show()
        {
            var da = new DataAccess();
            da.Connect();
            var com = new OleDbCommand();
            com.CommandText = "select * from UserPass";
            var dt = da.Docommand(com);
            da.Disconnect();
            return dt;
        }
    }
}